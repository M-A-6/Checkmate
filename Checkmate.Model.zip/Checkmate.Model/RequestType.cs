﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkmate.Model
{
    public enum RequestType
    {
        None =0,
        Approved =1,
        Rejected = 2,
        Canceled= 3
    }
}
