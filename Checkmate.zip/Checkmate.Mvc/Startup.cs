using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Checkmate.AppCreator;
using Checkmate.Business;
using Checkmate.Data;
using Checkmate.Model;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Checkmate.Mvc
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddTransient<IPasswordHasher<IdentityUser>, CustomPasswordHasher>();


            //services.AddDataProtection().UseCryptographicAlgorithms()
            //services.AddDbContextPool<AppDataDb>(options =>
            //                                  options.UseSqlServer(Configuration.GetConnectionString("ConnectionStringDB")));
            services.AddDbContextPool<AppDataDb>(options =>
                                            options.UseSqlServer(Configuration.GetConnectionString("ConnectionStringDB")));
            services.AddControllersWithViews().AddJsonOptions(opt => opt.JsonSerializerOptions.PropertyNamingPolicy = new CustomJsonNamingPolicy());
            services.AddMvc().AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = new CustomJsonNamingPolicy());
            services.AddTransient<IRequestService, RequestService>();
            services.AddIdentity<IdentityUser, IdentityRole>().AddEntityFrameworkStores<AppDataDb>().AddDefaultTokenProviders();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Account}/{action=Login}/{id?}");
            });
        }
    }
    public class CustomJsonNamingPolicy : JsonNamingPolicy
    {
        public override string ConvertName(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
            return name.ToLower();
        }
    }

   

    public class CustomPasswordHasher : IPasswordHasher<IdentityUser>
    {
        public string HashPassword(IdentityUser user, string password)
        {
            return CreateHash(password);
        }

        public PasswordVerificationResult VerifyHashedPassword(IdentityUser user, string hashedPassword, string providedPassword)
        {
            if (hashedPassword == CreateHash(providedPassword))
            {
                return PasswordVerificationResult.Success;
            }

            return PasswordVerificationResult.Failed;
        }

        private string CreateHash(string password)
        {
            MD5CryptoServiceProvider md5Crypt = new MD5CryptoServiceProvider();
            byte[] passBytes = Encoding.UTF8.GetBytes(password);
            passBytes = md5Crypt.ComputeHash(passBytes);
            StringBuilder strEncryptPass = new StringBuilder();
            foreach (byte passwordByte in passBytes)
            {
                strEncryptPass.Append(passwordByte.ToString("x2").ToLower());
            }
            return strEncryptPass.ToString();

        }

    }
}

